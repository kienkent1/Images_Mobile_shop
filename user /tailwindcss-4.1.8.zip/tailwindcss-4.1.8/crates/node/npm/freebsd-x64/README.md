# `@tailwindcss/oxide-freebsd-x64`

This is the **x86_64-unknown-freebsd** binary for `@tailwindcss/oxide`
